import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/igorgiledragovic-gile/kodi/refs/heads/main/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/BalkanDzo/balkandzo.github.io/raw/refs/heads/main/zips/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
